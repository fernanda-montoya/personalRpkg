test_that("log_summed_exps returns finite value", {
  expect_true(is.finite(log_summed_exps(1:2000)))
})
